import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { getAnalytics, isSupported, Analytics } from 'firebase/analytics';

/**
 * Firebase project configuration provided for "one-on-one-7-game".
 */
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyA_OneOnOne7Game_DefaultWebApiKey',
  projectId: 'one-on-one-7-game',
  authDomain: 'one-on-one-7-game.firebaseapp.com',
  storageBucket: 'one-on-one-7-game.firebasestorage.app',
  messagingSenderId: '331326093589',
  appId: '1:331326093589:web:fa78034fb6cbc113ac511c',
  measurementId: 'G-31RRYDNY3T',
};

// Initialize or retrieve existing Firebase App instance
export const app: FirebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore
export const db: Firestore = getFirestore(app);

// Initialize Auth
export const auth: Auth = getAuth(app);

// Initialize Analytics conditionally where environment supports it and a valid API key is present
let analyticsInstance: Analytics | null = null;
export const getFirebaseAnalytics = async (): Promise<Analytics | null> => {
  if (analyticsInstance) {
    return analyticsInstance;
  }

  // Only initialize analytics if a genuine, user-provided API key is present
  const configuredApiKey = import.meta.env.VITE_FIREBASE_API_KEY;
  const isRealApiKey =
    Boolean(configuredApiKey) &&
    !configuredApiKey.includes('Placeholder') &&
    !configuredApiKey.includes('DefaultWebApiKey');

  if (!isRealApiKey) {
    return null;
  }

  try {
    const supported = await isSupported();
    if (supported) {
      analyticsInstance = getAnalytics(app);
      return analyticsInstance;
    }
  } catch (err) {
    console.warn('Firebase Analytics initialization skipped:', err);
  }
  return null;
};

// Initialize Analytics safely only if a valid API key is provided
if (typeof window !== 'undefined' && import.meta.env.VITE_FIREBASE_API_KEY) {
  getFirebaseAnalytics().catch(() => {
    // Graceful fallback for non-browser or unsupported environments
  });
}

// Error handling types and utility for Firestore operations
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default app;
