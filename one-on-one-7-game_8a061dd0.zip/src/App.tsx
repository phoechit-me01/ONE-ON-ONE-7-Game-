/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from './firebase';
import { MobileContainer } from './components/MobileContainer';
import { TopHeader } from './components/TopHeader';
import { HomeScreen } from './components/HomeScreen';
import { LevelMapScreen } from './components/LevelMapScreen';
import { GameScreen } from './components/GameScreen';
import { BottomNavBar, NavTab } from './components/BottomNavBar';
import { EmptyTabPlaceholder } from './components/EmptyTabPlaceholder';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isLevelMapOpen, setIsLevelMapOpen] = useState(false);
  const [isPlayingGame, setIsPlayingGame] = useState(false);
  const [playingLevel, setPlayingLevel] = useState<number>(1);
  const [maxUnlockedLevel, setMaxUnlockedLevel] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('one_on_one_unlocked_level');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed) && parsed >= 1) {
          return parsed;
        }
      }
    } catch {
      // Safe fallback
    }
    return 1;
  });

  // Sync highest unlocked level from Firestore user document on load/auth change
  useEffect(() => {
    let unsubUser: (() => void) | null = null;
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      if (unsubUser) {
        unsubUser();
        unsubUser = null;
      }
      const email = user?.email?.toLowerCase().trim();
      const userId =
        email === 'mgphoechit770@gmail.com'
          ? 'user_phoe_chit'
          : email === 'tinmoeh09@gmail.com'
          ? 'user_tin_moe_hlaing'
          : user?.uid || 'user_phoe_chit';

      const userDocRef = doc(db, 'users', userId);
      unsubUser = onSnapshot(
        userDocRef,
        (snap) => {
          if (snap.exists()) {
            const data = snap.data();
            const highest = Number(data.unlocked_level || data.highest_level_unlocked || 1);
            if (!isNaN(highest) && highest >= 1) {
              setMaxUnlockedLevel((prev) => {
                const nextVal = Math.max(prev, highest);
                try {
                  localStorage.setItem('one_on_one_unlocked_level', String(nextVal));
                } catch {
                  // Safe fallback
                }
                return nextVal;
              });
            }
          }
        },
        () => {}
      );
    });

    return () => {
      unsubAuth();
      if (unsubUser) unsubUser();
    };
  }, []);

  const handleTabChange = (tab: NavTab) => {
    setActiveTab(tab);
    setIsLevelMapOpen(false);
    setIsPlayingGame(false);
  };

  const handleOpenLevelMap = () => {
    setActiveTab('home');
    setIsLevelMapOpen(true);
    setIsPlayingGame(false);
  };

  const handleBackToHome = () => {
    setIsLevelMapOpen(false);
    setIsPlayingGame(false);
  };

  const handleStartLevel = (levelToPlay: number) => {
    setPlayingLevel(levelToPlay);
    setIsPlayingGame(true);
  };

  const handleExitGame = () => {
    setIsPlayingGame(false);
    setIsLevelMapOpen(true);
  };

  const handleLevelUnlocked = (nextLevel: number) => {
    setMaxUnlockedLevel((prev) => {
      const nextVal = Math.max(prev, nextLevel);
      try {
        localStorage.setItem('one_on_one_unlocked_level', String(nextVal));
      } catch {
        // Safe fallback
      }
      return nextVal;
    });
  };

  // If active in GameScreen (Section 3 & 4), render the 100vh pure black gameplay screen
  if (isPlayingGame) {
    return (
      <GameScreen
        level={playingLevel}
        onExitGame={handleExitGame}
        onLevelUnlocked={handleLevelUnlocked}
      />
    );
  }

  return (
    <MobileContainer>
      {/* Main View Area */}
      {activeTab === 'home' ? (
        isLevelMapOpen ? (
          <LevelMapScreen
            onBackToHome={handleBackToHome}
            onStartLevel={handleStartLevel}
            unlockedLevel={maxUnlockedLevel}
          />
        ) : (
          <div className="w-full flex-1 flex flex-col overflow-y-auto">
            {/* Top Header with live currency and profile */}
            <TopHeader
              onProfileClick={() => handleTabChange('profile')}
              onShopClick={() => handleTabChange('shop')}
            />
            {/* Home Screen with Banner and 3 Showcase Slots */}
            <HomeScreen onGoToLevelMap={handleOpenLevelMap} />
          </div>
        )
      ) : (
        <div className="w-full flex-1 flex flex-col overflow-y-auto">
          <TopHeader
            onProfileClick={() => handleTabChange('profile')}
            onShopClick={() => handleTabChange('shop')}
          />
          <EmptyTabPlaceholder
            tab={activeTab}
            onGoHome={() => handleTabChange('home')}
          />
        </div>
      )}

      {/* Bottom Navigation Bar: Positioned at very bottom of 430px frame */}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />
    </MobileContainer>
  );
}
