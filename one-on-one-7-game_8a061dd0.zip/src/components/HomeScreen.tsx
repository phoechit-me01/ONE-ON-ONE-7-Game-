import React from 'react';
import { LevelMapBanner } from './LevelMapBanner';
import { ShowcaseSlots } from './ShowcaseSlots';

interface HomeScreenProps {
  onGoToLevelMap?: () => void;
}

/**
 * Home Screen Component
 * Structure directly beneath Top Header:
 * 1. "Go to Level Map" Banner ONLY (static trigger)
 * 2. Home Showcase Slots ("SHOWCASE YOUR GEAR" header + 3 static empty gear slots)
 * - Zero animations, completely static.
 */
export const HomeScreen: React.FC<HomeScreenProps> = ({
  onGoToLevelMap,
}) => {
  return (
    <div className="w-full flex-1 flex flex-col pb-6">
      {/* 1. "Go to Level Map" Banner */}
      <LevelMapBanner onGoToLevelMap={onGoToLevelMap} />

      {/* 2. Home Showcase Slots (3 empty gear slots side-by-side) */}
      <ShowcaseSlots />
    </div>
  );
};

export default HomeScreen;
