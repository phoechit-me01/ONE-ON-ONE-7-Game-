import React, { useState, useEffect, useRef, useCallback } from 'react';
import { doc, onSnapshot, setDoc, increment } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { transformGoogleDriveImageUrl } from './LevelDetailModal';
import { ArrowLeft, CheckCircle2, RotateCcw, Flag } from 'lucide-react';

interface GameScreenProps {
  level: number;
  onExitGame: () => void;
  onLevelUnlocked?: (nextLevel: number) => void;
}

type GridType = '4x3' | '6x4';

interface GridConfig {
  cols: number;
  rows: number;
  total: number;
  aspectRatio: string;
}

const GRID_CONFIGS: Record<GridType, GridConfig> = {
  '4x3': { cols: 4, rows: 3, total: 12, aspectRatio: '4 / 3' },
  '6x4': { cols: 6, rows: 4, total: 24, aspectRatio: '3 / 2' },
};

function formatMMSS(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

// Generate shuffled array of indices [0 ... count-1]
function generateShuffledTiles(count: number): number[] {
  const arr = Array.from({ length: count }, (_, i) => i);
  let isSorted = true;
  let attempts = 0;
  while (isSorted && attempts < 100) {
    attempts++;
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    let matches = 0;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] === i) matches++;
    }
    if (matches < count - 2) {
      isSorted = false;
    }
  }
  return arr;
}

/**
 * Section 3 & 4: Gameplay Screen & Database Sync Engine
 * Strict specifications:
 * - Max-width 430px, height 100vh, pure black background (#000000), vertical flex layout
 * - Top Header: Top-Left thumbnail (60x60, 1px solid #334155, radius 6px) + Metrics cluster (Time, Moves)
 * - Puzzle Board: Width 90%, #0F172A, border 2px solid #334155, radius 8px, cut lines 1px solid #475569
 * - Interaction: Tap-and-swap and drag/slide. Selected tile: border 2px solid #FEF08A & rgba(254,240,138,0.15)
 * - Special Level (level % 6 === 0): Numbers 1-12/24 overlay badge (rgba(0,0,0,0.5), 12px, weight 700, #FFFFFF)
 * - Zone 1: 4x3 & 6x4 Grid selector
 * - Zone 2: Restart (R++) & Give Up buttons
 * - Zone 3: "🔢 Show Number: Active" indicator on level % 6 === 0
 * - Section 4 Database Sync: Computes S_base, S_final, Gold, Gems, and writes to Firestore
 */
export const GameScreen: React.FC<GameScreenProps> = ({ level, onExitGame, onLevelUnlocked }) => {
  const [gridType, setGridType] = useState<GridType>('4x3');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [tiles, setTiles] = useState<number[]>(() => generateShuffledTiles(GRID_CONFIGS['4x3'].total));
  const [selectedTileIndex, setSelectedTileIndex] = useState<number | null>(null);

  // Gameplay Metrics
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [movesCount, setMovesCount] = useState<number>(0);
  const [restartsCount, setRestartsCount] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isGivenUp, setIsGivenUp] = useState<boolean>(false);

  // Result Metrics
  const [finalScore, setFinalScore] = useState<number>(0);
  const [earnedGold, setEarnedGold] = useState<number>(0);
  const [earnedGems, setEarnedGems] = useState<number>(0);

  const isSpecialLevel = level % 6 === 0;
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Instant Touch & Directional Gesture Mechanics Tracking
  const touchStartRef = useRef<{
    x: number;
    y: number;
    slot: number;
    swapped: boolean;
    hasMoved: boolean;
  } | null>(null);
  const lastTouchHandledTime = useRef<number>(0);

  // 1. Fetch Source Puzzle Image from `levels_master`
  useEffect(() => {
    let isMounted = true;
    const docRefPrimary = doc(db, 'levels_master', `level_${level}`);
    const docRefFallback = doc(db, 'levels_master', String(level));

    const unsubscribePrimary = onSnapshot(
      docRefPrimary,
      (docSnap) => {
        if (!isMounted) return;
        if (docSnap.exists() && docSnap.data()?.image_url) {
          const direct = transformGoogleDriveImageUrl(docSnap.data().image_url);
          setImageUrl(direct);
          return;
        }

        const unsubscribeFallback = onSnapshot(
          docRefFallback,
          (fbSnap) => {
            if (!isMounted) return;
            if (fbSnap.exists() && fbSnap.data()?.image_url) {
              const direct = transformGoogleDriveImageUrl(fbSnap.data().image_url);
              setImageUrl(direct);
            }
          },
          () => {}
        );
        return () => unsubscribeFallback();
      },
      (err) => {
        console.warn('levels_master fetch notice:', err.message);
      }
    );

    return () => {
      isMounted = false;
      unsubscribePrimary();
    };
  }, [level]);

  // 2. Timer
  useEffect(() => {
    if (isCompleted || isGivenUp) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setElapsedTime((prev) => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isCompleted, isGivenUp]);

  // Active user determination
  const getActiveUserId = useCallback((): string => {
    const currentUser = auth.currentUser;
    const email = currentUser?.email?.toLowerCase().trim();
    if (email === 'mgphoechit770@gmail.com') return 'user_phoe_chit';
    if (email === 'tinmoeh09@gmail.com') return 'user_tin_moe_hlaing';
    return currentUser?.uid || 'user_phoe_chit';
  }, []);

  // 3. Section 4: Reward Calculation Engine and Firestore Sync + Level Progression Unlock
  const handleLevelCompleted = useCallback(
    async (finalTime: number, finalMoves: number, finalRestarts: number, activeGrid: GridType) => {
      setIsCompleted(true);
      if (timerRef.current) clearInterval(timerRef.current);

      // Multipliers
      const Gm = activeGrid === '6x4' ? 1.5 : 1.0;
      const Sm = isSpecialLevel ? 1.5 : 1.0;
      // Show Number Deduction Multiplier: 0.75 if used, else 1.0
      const Dm = isSpecialLevel ? 0.75 : 1.0;

      // Base Score
      const Sbase = Math.max(100, 1000 - finalTime * 2 - finalMoves * 5 - finalRestarts * 50);
      const Sfinal = Math.floor(Sbase * Gm * Sm * Dm);

      // Currency Rewards
      let gold = Math.floor(Sfinal * 0.1);
      let gems = 0;

      if (isSpecialLevel) {
        // Special level with number active (+50 gold, 2 gems)
        gold += 50;
        gems = 2;
      } else {
        // Standard perfect run: R=0, T<=120, M<=30 -> 1 gem
        if (finalRestarts === 0 && finalTime <= 120 && finalMoves <= 30) {
          gems = 1;
        }
      }

      setFinalScore(Sfinal);
      setEarnedGold(gold);
      setEarnedGems(gems);

      // Immediate Level Unlock for Level L + 1
      const nextLevel = level < 100 ? level + 1 : 100;

      // Immediate local state callback (0ms lag, zero blocking)
      onLevelUnlocked?.(nextLevel);

      // Immediate local persistence (instant, resilient against network/permission states)
      try {
        localStorage.setItem('one_on_one_unlocked_level', String(nextLevel));
        localStorage.setItem(
          `one_on_one_level_${level}`,
          JSON.stringify({ status: 'completed', completed: true, level_id: level, score: Sfinal })
        );
      } catch {
        // Safe fallback
      }

      // Database Sync to Firestore
      try {
        const userId = getActiveUserId();
        const levelDocRefPrimary = doc(db, 'users', userId, 'level_progress', `level_${level}`);
        const levelDocRefFallback = doc(db, 'users', userId, 'level_progress', String(level));

        const completedPayload = {
          level_id: level,
          status: 'completed',
          completed: true,
          score: Sfinal,
          time_spent: finalTime,
          time: formatMMSS(finalTime),
          moves: finalMoves,
          restarts: finalRestarts,
          grid_type: activeGrid,
          number_used: isSpecialLevel ? 'Yes' : 'No',
          rewards: {
            gold,
            gems,
          },
          gold,
          gems,
          updated_at: new Date().toISOString(),
        };

        const currentAuthUid = auth.currentUser?.uid;
        const userDocRef = doc(db, 'users', userId);
        const userUpdatePayload = {
          gold: increment(gold),
          gems: increment(gems),
          unlocked_level: nextLevel,
          highest_level_unlocked: nextLevel,
        };

        const syncTasks: Promise<unknown>[] = [
          setDoc(levelDocRefPrimary, completedPayload, { merge: true }),
          setDoc(levelDocRefFallback, completedPayload, { merge: true }),
          setDoc(userDocRef, userUpdatePayload, { merge: true }),
        ];

        // Unlock next sequential level in Firestore at /users/{userId}/level_progress/level_{N+1}
        if (level < 100) {
          const nextLevelDocRefPrimary = doc(db, 'users', userId, 'level_progress', `level_${nextLevel}`);
          const nextLevelDocRefFallback = doc(db, 'users', userId, 'level_progress', String(nextLevel));
          const unlockPayload = {
            level_id: nextLevel,
            status: 'unlocked',
            unlocked: true,
            updated_at: new Date().toISOString(),
          };

          syncTasks.push(
            setDoc(nextLevelDocRefPrimary, unlockPayload, { merge: true }),
            setDoc(nextLevelDocRefFallback, unlockPayload, { merge: true })
          );
        }

        // Also sync to currentAuthUid if different from mapped userId
        if (currentAuthUid && currentAuthUid !== userId) {
          syncTasks.push(
            setDoc(doc(db, 'users', currentAuthUid, 'level_progress', `level_${level}`), completedPayload, { merge: true }),
            setDoc(doc(db, 'users', currentAuthUid, 'level_progress', `level_${nextLevel}`), {
              level_id: nextLevel,
              status: 'unlocked',
              unlocked: true,
              updated_at: new Date().toISOString(),
            }, { merge: true }),
            setDoc(doc(db, 'users', currentAuthUid), userUpdatePayload, { merge: true })
          );
        }

        await Promise.allSettled(syncTasks);
      } catch (err) {
        console.warn('Firestore completion sync notice:', err instanceof Error ? err.message : String(err));
      }
    },
    [level, isSpecialLevel, getActiveUserId, onLevelUnlocked]
  );

  // Check solved condition
  const checkSolved = useCallback(
    (currentTiles: number[]) => {
      const isSolved = currentTiles.every((val, idx) => val === idx);
      if (isSolved && !isCompleted && !isGivenUp) {
        handleLevelCompleted(elapsedTime, movesCount + 1, restartsCount, gridType);
      }
    },
    [isCompleted, isGivenUp, elapsedTime, movesCount, restartsCount, gridType, handleLevelCompleted]
  );

  // Swap two tiles with 0ms transition delay
  const handleSwap = useCallback(
    (fromIndex: number, toIndex: number) => {
      if (fromIndex === toIndex || isCompleted || isGivenUp) return;

      setTiles((prevTiles) => {
        const newTiles = [...prevTiles];
        [newTiles[fromIndex], newTiles[toIndex]] = [newTiles[toIndex], newTiles[fromIndex]];
        checkSolved(newTiles);
        return newTiles;
      });
      setMovesCount((m) => m + 1);
      setSelectedTileIndex(null);
    },
    [isCompleted, isGivenUp, checkSolved]
  );

  // Instant Tap-and-Swap handler (0ms response)
  const handleTileClick = useCallback(
    (index: number) => {
      if (isCompleted || isGivenUp) return;

      if (selectedTileIndex === null) {
        setSelectedTileIndex(index);
      } else if (selectedTileIndex === index) {
        setSelectedTileIndex(null); // Instant deselect
      } else {
        handleSwap(selectedTileIndex, index);
      }
    },
    [isCompleted, isGivenUp, selectedTileIndex, handleSwap]
  );

  const currentConfig = GRID_CONFIGS[gridType];

  // Touch Gesture Handlers: Directional Slide (Left, Right, Up, Down) & Drag-and-Drop
  const handleTouchStart = (e: React.TouchEvent, slot: number) => {
    if (isCompleted || isGivenUp) return;
    const touch = e.touches[0];
    touchStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      slot,
      swapped: false,
      hasMoved: false,
    };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isCompleted || isGivenUp || !touchStartRef.current || touchStartRef.current.swapped) return;

    const touch = e.touches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    const dist = Math.hypot(dx, dy);

    if (dist > 8) {
      touchStartRef.current.hasMoved = true;
    }

    // Directional Slide Threshold: 20px
    if (dist >= 20) {
      const slot = touchStartRef.current.slot;
      const cols = currentConfig.cols;
      const rows = currentConfig.rows;
      const col = slot % cols;
      const row = Math.floor(slot / cols);

      let targetSlot: number | null = null;

      if (Math.abs(dx) > Math.abs(dy)) {
        // Horizontal slide
        if (dx > 0 && col < cols - 1) {
          targetSlot = slot + 1; // Slide Right
        } else if (dx < 0 && col > 0) {
          targetSlot = slot - 1; // Slide Left
        }
      } else {
        // Vertical slide
        if (dy > 0 && row < rows - 1) {
          targetSlot = slot + cols; // Slide Down
        } else if (dy < 0 && row > 0) {
          targetSlot = slot - cols; // Slide Up
        }
      }

      if (targetSlot !== null && targetSlot >= 0 && targetSlot < currentConfig.total) {
        handleSwap(slot, targetSlot);
        touchStartRef.current.swapped = true;
        lastTouchHandledTime.current = Date.now();
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (isCompleted || isGivenUp || !touchStartRef.current) return;

    const currentTouch = touchStartRef.current;
    touchStartRef.current = null;
    lastTouchHandledTime.current = Date.now();

    // If directional slide already swapped tiles, do not re-swap
    if (currentTouch.swapped) {
      return;
    }

    // If user dragged to another target tile and released (drag & drop)
    if (currentTouch.hasMoved && e.changedTouches && e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      const targetElement = document.elementFromPoint(touch.clientX, touch.clientY);
      const tileContainer = targetElement?.closest('[data-slot-index]');
      if (tileContainer) {
        const dropSlotStr = tileContainer.getAttribute('data-slot-index');
        if (dropSlotStr !== null) {
          const dropSlot = Number(dropSlotStr);
          if (!isNaN(dropSlot) && dropSlot !== currentTouch.slot) {
            handleSwap(currentTouch.slot, dropSlot);
            return;
          }
        }
      }
    }

    // If pure tap without significant move, execute instant selection or swap (0ms lag)
    if (!currentTouch.hasMoved) {
      handleTileClick(currentTouch.slot);
    }
  };

  // Restart Handler
  const handleRestart = () => {
    if (isCompleted) return;
    setRestartsCount((r) => r + 1);
    setSelectedTileIndex(null);
    setTiles(generateShuffledTiles(GRID_CONFIGS[gridType].total));
  };

  // Grid Type Switcher
  const handleGridChange = (type: GridType) => {
    if (type === gridType || isCompleted) return;
    setGridType(type);
    setSelectedTileIndex(null);
    setTiles(generateShuffledTiles(GRID_CONFIGS[type].total));
  };

  // Give Up Handler: Marks level as given_up, unlocks Level L + 1, and updates DB
  const handleGiveUp = async () => {
    setIsGivenUp(true);
    if (timerRef.current) clearInterval(timerRef.current);

    // Dynamic next sequential level unlock calculation for universal level progression
    const nextLevel = level < 100 ? level + 1 : 100;

    // Immediate local persistence (instant, resilient against network/permission states)
    try {
      localStorage.setItem('one_on_one_unlocked_level', String(nextLevel));
      localStorage.setItem(
        `one_on_one_level_${level}`,
        JSON.stringify({ status: 'given_up', completed: false, level_id: level })
      );
    } catch {
      // Safe fallback
    }

    // Immediately trigger local state unlock (0ms delay, zero blocking)
    onLevelUnlocked?.(nextLevel);

    try {
      const userId = getActiveUserId();
      const levelDocRefPrimary = doc(db, 'users', userId, 'level_progress', `level_${level}`);
      const levelDocRefFallback = doc(db, 'users', userId, 'level_progress', String(level));

      const giveUpPayload = {
        level_id: level,
        status: 'given_up',
        completed: false,
        score: 0,
        time_spent: elapsedTime,
        time: formatMMSS(elapsedTime),
        moves: movesCount,
        restarts: restartsCount,
        grid_type: gridType,
        number_used: isSpecialLevel ? 'Yes' : 'No',
        rewards: { gold: 0, gems: 0 },
        gold: 0,
        gems: 0,
        updated_at: new Date().toISOString(),
      };

      const unlockPayload = {
        level_id: nextLevel,
        status: 'unlocked',
        unlocked: true,
        updated_at: new Date().toISOString(),
      };

      const userUpdatePayload = {
        unlocked_level: nextLevel,
        highest_level_unlocked: nextLevel,
      };

      const currentAuthUid = auth.currentUser?.uid;
      const userDocRef = doc(db, 'users', userId);

      const syncTasks: Promise<unknown>[] = [
        setDoc(levelDocRefPrimary, giveUpPayload, { merge: true }),
        setDoc(levelDocRefFallback, giveUpPayload, { merge: true }),
        setDoc(userDocRef, userUpdatePayload, { merge: true }),
      ];

      // Unlock next level N + 1 in Firestore at /users/{userId}/level_progress/level_{N+1}
      if (level < 100) {
        const nextLevelDocRefPrimary = doc(db, 'users', userId, 'level_progress', `level_${nextLevel}`);
        const nextLevelDocRefFallback = doc(db, 'users', userId, 'level_progress', String(nextLevel));

        syncTasks.push(
          setDoc(nextLevelDocRefPrimary, unlockPayload, { merge: true }),
          setDoc(nextLevelDocRefFallback, unlockPayload, { merge: true })
        );
      }

      // Sync to currentAuthUid if distinct from mapped profile ID
      if (currentAuthUid && currentAuthUid !== userId) {
        syncTasks.push(
          setDoc(doc(db, 'users', currentAuthUid, 'level_progress', `level_${level}`), giveUpPayload, { merge: true }),
          setDoc(doc(db, 'users', currentAuthUid, 'level_progress', `level_${nextLevel}`), unlockPayload, { merge: true }),
          setDoc(doc(db, 'users', currentAuthUid), userUpdatePayload, { merge: true })
        );
      }

      await Promise.allSettled(syncTasks);
    } catch (err) {
      console.warn('Firestore give-up sync notice:', err instanceof Error ? err.message : String(err));
    }
  };

  return (
    <div
      style={{
        maxWidth: '430px',
        height: '100vh',
        backgroundColor: '#000000',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box',
        color: '#FFFFFF',
        userSelect: 'none',
      }}
      className="w-full mx-auto relative overflow-y-auto"
    >
      {/* --- TOP HEADER PANEL --- */}
      {/* style: display: flex; justify-content: space-between; align-items: center; width: 100%; padding: 12px 16px; */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          padding: '12px 16px',
          boxSizing: 'border-box',
          borderBottom: '1px solid #1E293B',
        }}
      >
        {/* Top-Left: Original Image Thumbnail (60px x 60px, border 1px solid #334155, radius 6px) */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onExitGame}
            className="text-[#94A3B8] hover:text-[#FFFFFF] p-1 cursor-pointer focus:outline-none"
            aria-label="Exit Game"
            title="Exit Game"
          >
            <ArrowLeft size={20} />
          </button>

          <div
            style={{
              width: '60px',
              height: '60px',
              border: '1px solid #334155',
              borderRadius: '6px',
              overflow: 'hidden',
              backgroundColor: '#0F172A',
            }}
            className="flex items-center justify-center shrink-0"
          >
            {imageUrl ? (
              <img
                src={imageUrl}
                alt="Source Puzzle Preview"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            ) : (
              <span className="text-[10px] text-[#64748B]">Thumbnail</span>
            )}
          </div>
        </div>

        {/* Top-Right: Gameplay Metrics Cluster (display: flex; gap: 8px;) */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          {/* Time Box: Height 36px, padding 0 12px, bg #1E293B, border 1px solid #334155, radius 6px, 14px 600 #FFFFFF */}
          <div
            style={{
              height: '36px',
              padding: '0 12px',
              backgroundColor: '#1E293B',
              border: '1px solid #334155',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: 600,
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              whiteSpace: 'nowrap',
            }}
          >
            ⏱️ {formatMMSS(elapsedTime)}
          </div>

          {/* Move Box: Height 36px, padding 0 12px, bg #1E293B, border 1px solid #334155, radius 6px, 14px 600 #FFFFFF */}
          <div
            style={{
              height: '36px',
              padding: '0 12px',
              backgroundColor: '#1E293B',
              border: '1px solid #334155',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: 600,
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              whiteSpace: 'nowrap',
            }}
          >
            🔄 {movesCount}
          </div>
        </div>
      </div>

      {/* --- MAIN PUZZLE BOARD --- */}
      {/* Width 90%, aspect ratio mapped to standard dimensions, margin: 10px auto, Frame: bg #0F172A, border 2px solid #334155, radius 8px */}
      <div
        style={{
          width: '90%',
          aspectRatio: currentConfig.aspectRatio,
          margin: '10px auto',
          backgroundColor: '#0F172A',
          border: '2px solid #334155',
          borderRadius: '8px',
          overflow: 'hidden',
          display: 'grid',
          gridTemplateColumns: `repeat(${currentConfig.cols}, 1fr)`,
          gridTemplateRows: `repeat(${currentConfig.rows}, 1fr)`,
          boxSizing: 'border-box',
          position: 'relative',
          touchAction: 'none',
          userSelect: 'none',
        }}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {tiles.map((origIndex, currentSlot) => {
          const isSelected = selectedTileIndex === currentSlot;
          const origCol = origIndex % currentConfig.cols;
          const origRow = Math.floor(origIndex / currentConfig.cols);

          // Slicing math
          const bgPosX =
            currentConfig.cols > 1 ? (origCol / (currentConfig.cols - 1)) * 100 : 0;
          const bgPosY =
            currentConfig.rows > 1 ? (origRow / (currentConfig.rows - 1)) * 100 : 0;

          return (
            <div
              key={currentSlot}
              data-slot-index={currentSlot}
              role="button"
              tabIndex={0}
              onTouchStart={(e) => handleTouchStart(e, currentSlot)}
              onClick={() => {
                if (Date.now() - lastTouchHandledTime.current < 400) return;
                handleTileClick(currentSlot);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  handleTileClick(currentSlot);
                }
              }}
              draggable={!isCompleted && !isGivenUp}
              onDragStart={(e) => {
                e.dataTransfer.setData('text/plain', String(currentSlot));
              }}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                const from = Number(e.dataTransfer.getData('text/plain'));
                handleSwap(from, currentSlot);
              }}
              style={{
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                border: isSelected ? '2px solid #FEF08A' : '1px solid #475569',
                backgroundColor: isSelected ? 'rgba(254, 240, 138, 0.15)' : '#1E293B',
                backgroundImage: imageUrl ? `url(${imageUrl})` : undefined,
                backgroundSize: `${currentConfig.cols * 100}% ${currentConfig.rows * 100}%`,
                backgroundPosition: `${bgPosX}% ${bgPosY}%`,
                backgroundRepeat: 'no-repeat',
                position: 'relative',
                cursor: 'pointer',
                touchAction: 'none',
                transition: 'none',
              }}
            >
              {/* Selected Overlay highlight */}
              {isSelected && (
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    backgroundColor: 'rgba(254, 240, 138, 0.15)',
                    pointerEvents: 'none',
                    transition: 'none',
                  }}
                />
              )}

              {/* Special Level Number Overlay (Level Number % 6 === 0):
                  Display sequential numbers (1-12 for 4x3; 1-24 for 6x4) at the top-left of each tile
                  with semi-transparent dark background badge (rgba(0,0,0,0.5)), font size 12px, weight 700, color #FFFFFF */}
              {isSpecialLevel && (
                <div
                  style={{
                    position: 'absolute',
                    top: '2px',
                    left: '2px',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    fontSize: '12px',
                    fontWeight: 700,
                    color: '#FFFFFF',
                    padding: '1px 5px',
                    borderRadius: '4px',
                    lineHeight: '1.2',
                    pointerEvents: 'none',
                    transition: 'none',
                  }}
                >
                  {origIndex + 1}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* --- ZONE 1: GRID SELECTOR --- */}
      {/* 4x3 and 6x4 buttons (display: flex; gap: 12px; width: 90%; margin: 12px auto 6px auto) */}
      <div
        style={{
          display: 'flex',
          gap: '12px',
          width: '90%',
          margin: '12px auto 6px auto',
          boxSizing: 'border-box',
        }}
      >
        {/* 4x3 Button */}
        <button
          type="button"
          onClick={() => handleGridChange('4x3')}
          style={{
            flex: 1,
            height: '40px',
            borderRadius: '6px',
            fontWeight: 700,
            fontSize: '14px',
            cursor: 'pointer',
            backgroundColor: gridType === '4x3' ? '#FFFFFF' : '#1E293B',
            color: gridType === '4x3' ? '#000000' : '#64748B',
            border: gridType === '4x3' ? 'none' : '1px solid #334155',
          }}
        >
          4x3
        </button>

        {/* 6x4 Button */}
        <button
          type="button"
          onClick={() => handleGridChange('6x4')}
          style={{
            flex: 1,
            height: '40px',
            borderRadius: '6px',
            fontWeight: 700,
            fontSize: '14px',
            cursor: 'pointer',
            backgroundColor: gridType === '6x4' ? '#FFFFFF' : '#1E293B',
            color: gridType === '6x4' ? '#000000' : '#64748B',
            border: gridType === '6x4' ? 'none' : '1px solid #334155',
          }}
        >
          6x4
        </button>
      </div>

      {/* --- ZONE 2: GAME CONTROLS --- */}
      {/* Width 90%, margin 6px auto, flex-direction column, gap 8px */}
      <div
        style={{
          width: '90%',
          margin: '6px auto',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          boxSizing: 'border-box',
        }}
      >
        {/* Restart Button: bg #334155, text #FFFFFF, height 42px, label "🔄 Restart" */}
        <button
          type="button"
          onClick={handleRestart}
          disabled={isCompleted || isGivenUp}
          style={{
            backgroundColor: '#334155',
            color: '#FFFFFF',
            height: '42px',
            borderRadius: '6px',
            fontWeight: 600,
            fontSize: '14px',
            border: 'none',
            cursor: isCompleted || isGivenUp ? 'not-allowed' : 'pointer',
            opacity: isCompleted || isGivenUp ? 0.6 : 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px',
          }}
        >
          <RotateCcw size={15} />
          <span>Restart</span>
        </button>

        {/* Give Up Button: bg #991B1B, text #FFFFFF, height 42px, label "🏳️ Give Up" */}
        <button
          type="button"
          onClick={handleGiveUp}
          disabled={isCompleted || isGivenUp}
          style={{
            backgroundColor: '#991B1B',
            color: '#FFFFFF',
            height: '42px',
            borderRadius: '6px',
            fontWeight: 600,
            fontSize: '14px',
            border: 'none',
            cursor: isCompleted || isGivenUp ? 'not-allowed' : 'pointer',
            opacity: isCompleted || isGivenUp ? 0.6 : 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px',
          }}
        >
          <Flag size={15} />
          <span>Give Up</span>
        </button>
      </div>

      {/* --- ZONE 3: SPECIAL LEVEL INDICATOR --- */}
      {/* Visible strictly on levels where Level Number % 6 === 0 */}
      {isSpecialLevel && (
        <div
          style={{
            backgroundColor: '#0F172A',
            border: '1px solid #0284C7',
            color: '#38BDF8',
            fontSize: '13px',
            fontWeight: 600,
            height: '36px',
            width: '90%',
            margin: '6px auto 14px auto',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '6px',
            boxSizing: 'border-box',
          }}
        >
          🔢 Show Number: Active
        </div>
      )}

      {/* --- COMPLETION MODAL --- */}
      {isCompleted && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            zIndex: 1100,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
        >
          <div
            style={{
              width: '90%',
              maxWidth: '360px',
              backgroundColor: '#1E293B',
              borderRadius: '16px',
              border: '2px solid #334155',
              padding: '24px 20px',
              color: '#FFFFFF',
              textAlign: 'center',
            }}
          >
            <div className="w-14 h-14 rounded-full bg-[#10B981]/20 border border-[#10B981] flex items-center justify-center text-[#10B981] mx-auto mb-3">
              <CheckCircle2 size={32} />
            </div>

            <h2 className="text-[20px] font-bold text-white mb-1">
              Level {level} Completed!
            </h2>
            <p className="text-[12px] text-[#94A3B8] mb-4">
              Results successfully synced to database
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs mb-3 text-left">
              <div className="bg-[#0F172A] p-2.5 rounded-[8px] border border-[#334155]">
                <span className="text-[10px] text-[#94A3B8] uppercase block">Final Score</span>
                <span className="text-[15px] font-bold text-white">{finalScore.toLocaleString()}</span>
              </div>
              <div className="bg-[#0F172A] p-2.5 rounded-[8px] border border-[#334155]">
                <span className="text-[10px] text-[#94A3B8] uppercase block">Time</span>
                <span className="text-[15px] font-bold text-white">{formatMMSS(elapsedTime)}</span>
              </div>
              <div className="bg-[#0F172A] p-2.5 rounded-[8px] border border-[#334155]">
                <span className="text-[10px] text-[#94A3B8] uppercase block">Moves</span>
                <span className="text-[15px] font-bold text-white">{movesCount}</span>
              </div>
              <div className="bg-[#0F172A] p-2.5 rounded-[8px] border border-[#334155]">
                <span className="text-[10px] text-[#94A3B8] uppercase block">Restarts</span>
                <span className="text-[15px] font-bold text-white">{restartsCount}</span>
              </div>
            </div>

            {/* Currency Rewards Card */}
            <div className="bg-[#0F172A] p-3 rounded-[8px] border border-[#334155] mb-5 flex items-center justify-between text-xs">
              <span className="text-[#94A3B8] uppercase font-semibold">Rewards Earned</span>
              <div className="flex items-center gap-3">
                <span className="font-bold text-white flex items-center gap-1">
                  🪙 +{earnedGold.toLocaleString()}
                </span>
                <span className="font-bold text-white flex items-center gap-1">
                  💎 +{earnedGems.toLocaleString()}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onExitGame}
              className="w-full h-[44px] bg-[#E65C65] text-white font-bold rounded-[8px] cursor-pointer hover:bg-[#d44851] focus:outline-none"
            >
              Continue to Level Map
            </button>
          </div>
        </div>
      )}

      {/* --- GIVE UP MODAL --- */}
      {isGivenUp && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            zIndex: 1100,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
        >
          <div
            style={{
              width: '90%',
              maxWidth: '360px',
              backgroundColor: '#1E293B',
              borderRadius: '16px',
              border: '2px solid #334155',
              padding: '24px 20px',
              color: '#FFFFFF',
              textAlign: 'center',
            }}
          >
            <div className="w-14 h-14 rounded-full bg-[#991B1B]/20 border border-[#EF4444] flex items-center justify-center text-[#EF4444] mx-auto mb-3">
              <Flag size={28} />
            </div>

            <h2 className="text-[20px] font-bold text-white mb-1">
              Stage Surrendered
            </h2>
            <p className="text-[12px] text-[#94A3B8] mb-5">
              Level {level} marked as given up (Score: 0, Rewards: 0).
            </p>

            <button
              type="button"
              onClick={onExitGame}
              className="w-full h-[44px] bg-[#334155] text-white font-bold rounded-[8px] cursor-pointer hover:bg-[#475569] focus:outline-none"
            >
              Return to Level Map
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameScreen;
