import React, { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase';

export interface TopHeaderProps {
  gold?: number;
  gems?: number;
  onProfileClick?: () => void;
  onShopClick?: () => void;
}

/**
 * Number formatting logic:
 * - Small amounts shown with commas (e.g., 1,250)
 * - Amounts >= 10K shortened (e.g., 10K, 1.5M)
 * - 0 or uninitialized defaults to '0'
 */
export function formatCurrency(amount: number): string {
  if (amount == null || isNaN(amount) || amount <= 0) return '0';
  if (amount >= 1_000_000) {
    const formatted = (amount / 1_000_000).toFixed(1).replace(/\.0$/, '');
    return `${formatted}M`;
  }
  if (amount >= 10_000) {
    const formatted = (amount / 1_000).toFixed(1).replace(/\.0$/, '');
    return `${formatted}K`;
  }
  return amount.toLocaleString('en-US');
}

/**
 * Dynamic Name Binding:
 * - Email = mgphoechit770@gmail.com -> PHOE CHIT
 * - Email = tinmoeh09@gmail.com -> Tin Moe Hlaing
 */
function resolveDisplayName(email?: string | null): string {
  if (!email) return 'PHOE CHIT';
  const cleanEmail = email.toLowerCase().trim();
  if (cleanEmail === 'mgphoechit770@gmail.com') {
    return 'PHOE CHIT';
  }
  if (cleanEmail === 'tinmoeh09@gmail.com') {
    return 'Tin Moe Hlaing';
  }
  return email.split('@')[0];
}

/**
 * Section 2A Top Header Component
 * Strict specifications:
 * - Fixed/Sticky at top of mobile container
 * - Height: 60px, Padding: Left/Right 16px, Top/Bottom 10px
 * - Background: #FAF8F5, Border Bottom: 1px solid #E2E8F0
 * - Completely static, zero animations or transitions
 * - Left: User avatar (40x40 circle, 2px solid #E65C65 border, 👤 icon), User Name (14px, 600, #2C3E50, max-width 110px, ellipsis)
 * - Center: Completely empty
 * - Right: Real dynamic Gold (🪙) and Gem (💎) currency counters from Firestore user doc, defaulting to 0
 */
export const TopHeader: React.FC<TopHeaderProps> = ({
  gold: propGold,
  gems: propGems,
  onProfileClick,
  onShopClick,
}) => {
  const [displayName, setDisplayName] = useState<string>('PHOE CHIT');
  const [dbGold, setDbGold] = useState<number>(0);
  const [dbGems, setDbGems] = useState<number>(0);

  useEffect(() => {
    let unsubscribeFirestore: (() => void) | null = null;

    // Listen to Firebase Auth state
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
        unsubscribeFirestore = null;
      }

      if (user) {
        setDisplayName(resolveDisplayName(user.email));

        const cleanEmail = user.email?.toLowerCase().trim();
        const targetUserId =
          cleanEmail === 'mgphoechit770@gmail.com'
            ? 'user_phoe_chit'
            : cleanEmail === 'tinmoeh09@gmail.com'
            ? 'user_tin_moe_hlaing'
            : user.uid;

        // Real Firestore Data Binding: Listen to the authenticated user's document in users collection
        const userDocRef = doc(db, 'users', targetUserId);
        unsubscribeFirestore = onSnapshot(
          userDocRef,
          (docSnap) => {
            if (docSnap.exists()) {
              const data = docSnap.data();
              const parsedGold = Number(
                data.gold ??
                data.coins ??
                data.goldBalance ??
                data.currency?.gold ??
                data.currencies?.gold ??
                0
              );
              const parsedGems = Number(
                data.gems ??
                data.gem ??
                data.gemBalance ??
                data.currency?.gems ??
                data.currencies?.gems ??
                0
              );
              setDbGold(isNaN(parsedGold) ? 0 : parsedGold);
              setDbGems(isNaN(parsedGems) ? 0 : parsedGems);
            } else {
              // Not yet initialized for a new user, defaults to 0
              setDbGold(0);
              setDbGems(0);
            }
          },
          (error) => {
            console.warn('Firestore currency subscription notice:', error.message);
            setDbGold(0);
            setDbGems(0);
          }
        );
      } else {
        setDisplayName('PHOE CHIT');
        setDbGold(0);
        setDbGems(0);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
      }
    };
  }, []);

  const displayGold = propGold !== undefined ? propGold : dbGold;
  const displayGems = propGems !== undefined ? propGems : dbGems;

  const handleProfilePress = () => {
    if (onProfileClick) {
      onProfileClick();
    }
  };

  const handleShopPress = () => {
    if (onShopClick) {
      onShopClick();
    }
  };

  return (
    <header
      className="sticky top-0 z-50 w-full h-[60px] bg-[#FAF8F5] border-b border-[#E2E8F0] px-[16px] py-[10px] flex items-center justify-between select-none"
      style={{ boxSizing: 'border-box' }}
    >
      {/* --- Left Side: User Profile & Name Display --- */}
      <div
        role="button"
        tabIndex={0}
        onClick={handleProfilePress}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            handleProfilePress();
          }
        }}
        className="flex items-center cursor-pointer focus:outline-none"
        aria-label="User Profile"
      >
        {/* Profile Avatar: Circle shape (50%), 40px x 40px, border: 2px solid #E65C65 */}
        <div
          className="w-[40px] h-[40px] rounded-full border-2 border-[#E65C65] bg-[#FFFFFF] flex items-center justify-center shrink-0 text-[18px]"
          style={{ width: '40px', height: '40px' }}
        >
          <span>👤</span>
        </div>

        {/* User Name Display: margin-left: 8px, font-size: 14px, font-weight: 600, color: #2C3E50, max-width: 110px, ellipsis */}
        <span
          className="ml-[8px] text-[14px] font-semibold text-[#2C3E50] max-w-[110px] whitespace-nowrap overflow-hidden text-ellipsis inline-block"
          title={displayName}
        >
          {displayName}
        </span>
      </div>

      {/* --- Center Section: Completely clean and empty --- */}
      <div className="flex-1" aria-hidden="true" />

      {/* --- Right Side: Gold & Gem Currency Counters --- */}
      <div className="flex items-center gap-[8px] shrink-0">
        {/* Gold Counter Box (🪙): Height 32px, Background #FFFFFF, Border 1px solid #E2E8F0, Radius 20px, Padding 4px 10px */}
        <div
          role="button"
          tabIndex={0}
          onClick={handleShopPress}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              handleShopPress();
            }
          }}
          className="h-[32px] bg-[#FFFFFF] border border-[#E2E8F0] rounded-[20px] px-[10px] py-[4px] flex items-center gap-[4px] cursor-pointer focus:outline-none"
          aria-label={`Gold: ${displayGold}`}
        >
          <span className="text-[14px] leading-none">🪙</span>
          <span className="text-[13px] font-bold text-[#2C3E50] leading-none">
            {formatCurrency(displayGold)}
          </span>
        </div>

        {/* Gem Counter Box (💎): Height 32px, Background #FFFFFF, Border 1px solid #E2E8F0, Radius 20px, Padding 4px 10px */}
        <div
          role="button"
          tabIndex={0}
          onClick={handleShopPress}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              handleShopPress();
            }
          }}
          className="h-[32px] bg-[#FFFFFF] border border-[#E2E8F0] rounded-[20px] px-[10px] py-[4px] flex items-center gap-[4px] cursor-pointer focus:outline-none"
          aria-label={`Gems: ${displayGems}`}
        >
          <span className="text-[14px] leading-none">💎</span>
          <span className="text-[13px] font-bold text-[#2C3E50] leading-none">
            {formatCurrency(displayGems)}
          </span>
        </div>
      </div>
    </header>
  );
};

export default TopHeader;
