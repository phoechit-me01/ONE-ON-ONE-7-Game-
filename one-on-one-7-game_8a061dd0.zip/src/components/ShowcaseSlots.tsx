import React from 'react';
import { Plus } from 'lucide-react';

/**
 * Home Showcase Slots Component
 * Strict specifications:
 * - Positioned directly below the "Go to Level Map" Banner
 * - Section Header: "SHOWCASE YOUR GEAR" (Font Size: 12px, Uppercase, Color: #8E9AAF, margin-top: 24px)
 * - Structure: Exactly 3 empty gear slots side-by-side
 * - STRICT CONSTRAINT: No interactive item selection popups, inventory drawers,
 *   or automatic item listings. The slots remain static empty slots.
 * - Zero animations, completely static.
 */
export const ShowcaseSlots: React.FC = () => {
  return (
    <section className="w-full px-4 select-none mt-[24px]">
      {/* Section Header */}
      <h2 className="text-[12px] font-bold uppercase tracking-wider text-[#8E9AAF] mb-3">
        SHOWCASE YOUR GEAR
      </h2>

      {/* Exactly 3 empty gear slots side-by-side */}
      <div className="grid grid-cols-3 gap-3 w-full">
        {[1, 2, 3].map((slotNumber) => (
          <div
            key={slotNumber}
            className="h-[110px] rounded-[12px] p-2.5 flex flex-col items-center justify-between border border-[#E2E8F0] bg-[#FFFFFF] shadow-[0px_2px_8px_rgba(0,0,0,0.04)]"
            aria-label={`Gear Slot ${slotNumber}: Empty Slot`}
          >
            {/* Slot Header Label */}
            <div className="w-full flex items-center justify-start">
              <span className="text-[10px] font-semibold text-[#8E9AAF] uppercase">
                Slot {slotNumber}
              </span>
            </div>

            {/* Static Empty Slot Icon & Label */}
            <div className="flex flex-col items-center justify-center my-auto">
              <div className="w-9 h-9 rounded-full border border-dashed border-[#CBD5E1] flex items-center justify-center mb-1 bg-[#FAF8F5]">
                <Plus size={16} className="text-[#8E9AAF]" />
              </div>
              <span className="text-[10px] font-medium text-[#8E9AAF]">
                Empty Slot
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ShowcaseSlots;
