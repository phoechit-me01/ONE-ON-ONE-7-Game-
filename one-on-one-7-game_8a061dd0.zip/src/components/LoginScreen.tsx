import React, { useState, useEffect } from 'react';
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import { Mail, Lock, Eye, EyeOff, CheckCircle2, AlertCircle, LogOut } from 'lucide-react';
import { auth } from '../firebase';
import { HeartLogo } from './HeartLogo';

const PRE_REGISTERED_ACCOUNTS = [
  'mgphoechit770@gmail.com',
  'tinmoeh09@gmail.com',
];

export const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Monitor Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user?.email) {
        // Pre-fill email if already authenticated
        setEmail(user.email);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSelectAccount = (accountEmail: string) => {
    setEmail(accountEmail);
    setErrorMessage(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setErrorMessage('Please enter your email address.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);

    try {
      await signInWithEmailAndPassword(auth, trimmedEmail, password);
      // Successful login
      setErrorMessage(null);
    } catch (err: unknown) {
      console.error('Firebase Auth Login Error:', err);
      let friendlyMessage = 'Unable to login. Please check your credentials and try again.';
      if (err && typeof err === 'object' && 'code' in err) {
        const authError = err as { code: string; message: string };
        switch (authError.code) {
          case 'auth/invalid-credential':
          case 'auth/wrong-password':
          case 'auth/user-not-found':
            friendlyMessage = 'Invalid email or password. Please verify your credentials.';
            break;
          case 'auth/invalid-api-key':
          case 'auth/api-key-not-valid':
            friendlyMessage = 'Firebase API Key is missing or invalid. Please check VITE_FIREBASE_API_KEY.';
            break;
          case 'auth/invalid-email':
            friendlyMessage = 'Please enter a valid email address.';
            break;
          case 'auth/user-disabled':
            friendlyMessage = 'This account has been disabled. Please contact support.';
            break;
          case 'auth/too-many-requests':
            friendlyMessage = 'Too many attempts. Please try again in a few moments.';
            break;
          case 'auth/network-request-failed':
            friendlyMessage = 'Network connection error. Please check your internet connection.';
            break;
          default:
            friendlyMessage = authError.message || friendlyMessage;
        }
      }
      setErrorMessage(friendlyMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setPassword('');
      setErrorMessage(null);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <div className="w-full flex justify-center items-center min-h-screen bg-[#F5F2EC] p-0 sm:py-6">
      {/* 
        Strict Layout: Mobile-first container strictly constrained to max-width 430px, 
        portrait orientation, centered on the screen. Background Primary: #FAF8F5.
      */}
      <div className="w-full max-w-[430px] min-h-screen sm:min-h-[820px] bg-[#FAF8F5] sm:rounded-[36px] sm:shadow-[0_20px_50px_rgba(44,62,80,0.12)] flex flex-col items-center justify-between py-10 px-4 relative overflow-hidden">
        
        {/* Subtle decorative background warmth blobs */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-[#FFEFEF] rounded-full blur-3xl opacity-70 pointer-events-none -z-0" />
        <div className="absolute bottom-10 right-0 w-60 h-60 bg-[#FFF5EB] rounded-full blur-2xl opacity-60 pointer-events-none -z-0" />

        {/* --- TOP BRANDING SECTION --- */}
        <div className="w-full flex flex-col items-center pt-3 pb-2 z-10">
          {/* Animated Heart Logo: Compact, well-proportioned, directly above title */}
          <HeartLogo size={82} className="mb-3.5" />

          {/* Title Text */}
          <h1
            className="font-bold text-[#2C3E50] tracking-[1.5px] select-none text-center"
            style={{ fontSize: '24px', letterSpacing: '1.5px' }}
          >
            ONE ON ONE 7
          </h1>

          <p className="text-[12px] text-[#8E9AAF] tracking-wider uppercase font-medium mt-1">
            Our Private Sanctuary
          </p>
        </div>

        {/* --- MAIN LOGIN CARD CONTAINER --- */}
        {/*
          Specifications:
          - Width: 90% (Max-width 380px)
          - Background: #FFFFFF
          - Border Radius: 24px
          - Padding: 32px 24px
          - Shadow: 0px 12px 35px rgba(230, 92, 101, 0.08)
        */}
        <div
          className="w-[90%] max-w-[380px] bg-[#FFFFFF] rounded-[24px] px-6 py-8 shadow-[0px_12px_35px_rgba(230,92,101,0.08)] z-10 flex flex-col border border-[#F6EBEB]/50 my-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <h2
              className="font-bold text-[#2C3E50] select-none"
              style={{ fontSize: '22px' }}
            >
              Login
            </h2>

            {/* Status indicator if already logged in */}
            {currentUser && (
              <span className="inline-flex items-center gap-1.5 text-[11px] font-medium bg-[#EEF8F1] text-[#2E7D32] px-2.5 py-1 rounded-full">
                <CheckCircle2 size={12} />
                Connected
              </span>
            )}
          </div>

          {/* Connected User Active Session Banner */}
          {currentUser && (
            <div className="mb-5 p-3 rounded-[16px] bg-[#FBF8F6] border border-[#F0E6DE] flex items-center justify-between text-xs">
              <div className="flex flex-col truncate pr-2">
                <span className="text-[#8E9AAF] text-[10px] uppercase font-semibold">Active Session</span>
                <span className="text-[#2C3E50] font-medium truncate">{currentUser.email}</span>
              </div>
              <button
                type="button"
                onClick={handleSignOut}
                className="flex items-center gap-1 text-[#E65C65] font-semibold hover:text-[#d44851] text-xs px-2 py-1 rounded-lg transition-colors cursor-pointer"
                title="Sign out of current account"
              >
                <LogOut size={13} />
                <span>Sign Out</span>
              </button>
            </div>
          )}

          {/* Pre-registered quick-select accounts */}
          <div className="mb-5">
            <span className="text-[11px] text-[#8E9AAF] font-medium block mb-2">
              Pre-registered Accounts:
            </span>
            <div className="flex flex-col gap-1.5">
              {PRE_REGISTERED_ACCOUNTS.map((acc) => {
                const isSelected = email === acc;
                return (
                  <button
                    key={acc}
                    type="button"
                    onClick={() => handleSelectAccount(acc)}
                    className={`w-full text-left text-xs px-3 py-2 rounded-[10px] transition-all flex items-center justify-between cursor-pointer border ${
                      isSelected
                        ? 'bg-[#FFF5F6] border-[#FFCCD2] text-[#E65C65] font-medium'
                        : 'bg-[#FAF8F5] border-[#EAE3DC] text-[#637282] hover:bg-[#F5F0EA]'
                    }`}
                  >
                    <span className="truncate">{acc}</span>
                    {isSelected && <span className="w-2 h-2 rounded-full bg-[#E65C65]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Error Message Alert */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded-[12px] bg-[#FFF2F2] border border-[#FFD5D5] flex items-start gap-2 text-xs text-[#D9383A] animate-fadeIn">
              <AlertCircle size={15} className="mt-0.5 shrink-0" />
              <div className="leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            {/* Email Input Field */}
            <div>
              <label
                htmlFor="login-email"
                className="block text-[13px] font-medium text-[#8E9AAF] mb-1.5"
              >
                Email Address
              </label>
              <div
                className="relative flex items-center w-full h-[52px] rounded-[14px] border border-[#E2E8F0] bg-[#FFFFFF] px-3.5 transition-all focus-within:border-[#E65C65] focus-within:ring-2 focus-within:ring-[#E65C65]/20"
              >
                <Mail size={18} className="text-[#8E9AAF] shrink-0 mr-2.5" />
                <input
                  id="login-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="mgphoechit770@gmail.com"
                  autoComplete="email"
                  className="w-full h-full bg-transparent text-[14px] text-[#2C3E50] placeholder-[#B5BFC9] focus:outline-none"
                />
              </div>
            </div>

            {/* Password Input Field */}
            <div>
              <label
                htmlFor="login-password"
                className="block text-[13px] font-medium text-[#8E9AAF] mb-1.5"
              >
                Password
              </label>
              <div
                className="relative flex items-center w-full h-[52px] rounded-[14px] border border-[#E2E8F0] bg-[#FFFFFF] px-3.5 transition-all focus-within:border-[#E65C65] focus-within:ring-2 focus-within:ring-[#E65C65]/20"
              >
                <Lock size={18} className="text-[#8E9AAF] shrink-0 mr-2.5" />
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  className="w-full h-full bg-transparent text-[14px] text-[#2C3E50] placeholder-[#B5BFC9] focus:outline-none pr-8"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 p-1 text-[#8E9AAF] hover:text-[#2C3E50] transition-colors cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            {/*
              Specifications:
              - Text: "Login to Our Space"
              - Height: 54px
              - Width: 100%
              - Radius: 16px
              - Background: linear-gradient(135deg, #E65C65 0%, #FF8FA3 100%)
            */}
            <button
              type="submit"
              disabled={isLoading}
              className="mt-2 w-full h-[54px] rounded-[16px] text-white font-semibold text-[15px] tracking-wide shadow-[0_8px_20px_rgba(230,92,101,0.28)] hover:shadow-[0_10px_24px_rgba(230,92,101,0.36)] active:scale-[0.985] transition-all flex items-center justify-center cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
              style={{
                background: 'linear-gradient(135deg, #E65C65 0%, #FF8FA3 100%)',
              }}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <svg
                    className="animate-spin h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  <span>Connecting...</span>
                </div>
              ) : (
                <span>Login to Our Space</span>
              )}
            </button>
          </form>
        </div>

        {/* --- FOOTER / SECURITY CAPTION --- */}
        <div className="text-center pt-4 z-10">
          <p className="text-[12px] text-[#A0ABB8] font-normal">
            Protected &amp; Encrypted for Two Hearts
          </p>
        </div>

      </div>
    </div>
  );
};
